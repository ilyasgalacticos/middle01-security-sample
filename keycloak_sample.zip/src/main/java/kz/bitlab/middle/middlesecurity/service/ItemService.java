package kz.bitlab.middle.middlesecurity.service;

import kz.bitlab.middle.middlesecurity.dto.ItemDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ItemService {
    public List<ItemDto> getItems(){
        List<ItemDto> items = new ArrayList<>();
        items.add(ItemDto.builder().id(1L).name("Iphone 14").price(560000).amount(10).build());
        items.add(ItemDto.builder().id(2L).name("Iphone 15").price(660000).amount(20).build());
        items.add(ItemDto.builder().id(3L).name("Iphone 12").price(360000).amount(30).build());
        items.add(ItemDto.builder().id(4L).name("Iphone 13").price(460000).amount(40).build());
        items.add(ItemDto.builder().id(5L).name("Iphone 11").price(260000).amount(50).build());
        return items;
    }
}