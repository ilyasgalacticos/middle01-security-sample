package kz.bitlab.middle.middlesecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiddlesecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
